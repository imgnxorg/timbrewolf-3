#!/bin/zsh

./src/back/src/cli/main.sh
